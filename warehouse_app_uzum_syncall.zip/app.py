from __future__ import annotations

import os
from datetime import datetime, timedelta, date

from flask import Flask, jsonify, request, send_from_directory, render_template
from flask_cors import CORS
from sqlalchemy import create_engine, select, func, desc
from sqlalchemy.orm import sessionmaker

from models import Base, Product, Sale

APP_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(APP_DIR, "data")
DB_PATH = os.path.join(DATA_DIR, "app.db")
DB_URL = f"sqlite:///{DB_PATH}"

os.makedirs(DATA_DIR, exist_ok=True)

engine = create_engine(DB_URL, echo=False, future=True)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True)

Base.metadata.create_all(engine)

app = Flask(__name__, template_folder="templates", static_folder="static")
CORS(app)  # allows hosting UI elsewhere too

def product_to_dict(p: Product, last30_sales: int | None = None):
    d = {
        "id": p.id,
        "name": p.name,
        "sku": p.sku,
        "barcode": p.barcode,
        "quantity": p.quantity,
        "image_url": p.image_url,
        "created_at": p.created_at.isoformat() if p.created_at else None,
        "updated_at": p.updated_at.isoformat() if p.updated_at else None,
    }
    if last30_sales is not None:
        d["last_30_days_sales"] = int(last30_sales)
    return d

@app.get("/")
def index():
    return render_template("index.html")

@app.get("/api/health")
def health():
    return jsonify({"ok": True, "db": DB_PATH})

@app.get("/api/products")
def list_products():
    # Optional query params:
    # q=search string
    # sort=name|quantity|last30
    # dir=asc|desc
    q = (request.args.get("q") or "").strip().lower()
    sort = (request.args.get("sort") or "name").strip().lower()
    direction = (request.args.get("dir") or "asc").strip().lower()

    days = int(request.args.get("days") or 30)
    since = date.today() - timedelta(days=days)

    with SessionLocal() as db:
        # subquery: sales sum per product in last N days
        sales_subq = (
            select(Sale.product_id, func.coalesce(func.sum(Sale.qty_sold), 0).label("sales_sum"))
            .where(Sale.date >= since)
            .group_by(Sale.product_id)
            .subquery()
        )

        stmt = (
            select(Product, func.coalesce(sales_subq.c.sales_sum, 0).label("sales_sum"))
            .outerjoin(sales_subq, Product.id == sales_subq.c.product_id)
        )

        if q:
            like = f"%{q}%"
            stmt = stmt.where(
                func.lower(Product.name).like(like) |
                func.lower(func.coalesce(Product.sku, "")).like(like) |
                func.lower(func.coalesce(Product.barcode, "")).like(like)
            )

        # Sorting
        sort_col = None
        if sort == "quantity":
            sort_col = Product.quantity
        elif sort == "last30":
            sort_col = func.coalesce(sales_subq.c.sales_sum, 0)
        else:
            sort_col = func.lower(Product.name)

        if direction == "desc":
            stmt = stmt.order_by(desc(sort_col), Product.id.desc())
        else:
            stmt = stmt.order_by(sort_col, Product.id.asc())

        rows = db.execute(stmt).all()
        items = [product_to_dict(p, last30_sales=s) for (p, s) in rows]
        return jsonify({"items": items, "days": days})

@app.post("/api/products")
def create_product():
    data = request.get_json(force=True, silent=True) or {}
    name = (data.get("name") or "").strip()
    if not name:
        return jsonify({"error": "name is required"}), 400

    sku = (data.get("sku") or "").strip() or None
    barcode = (data.get("barcode") or "").strip() or None
    image_url = (data.get("image_url") or "").strip() or None

    try:
        quantity = int(data.get("quantity") or 0)
    except Exception:
        return jsonify({"error": "quantity must be an integer"}), 400

    with SessionLocal() as db:
        p = Product(name=name, sku=sku, barcode=barcode, quantity=quantity, image_url=image_url)
        db.add(p)
        db.commit()
        db.refresh(p)
        return jsonify(product_to_dict(p)), 201

@app.get("/api/products/<int:product_id>")
def get_product(product_id: int):
    with SessionLocal() as db:
        p = db.get(Product, product_id)
        if not p:
            return jsonify({"error": "not found"}), 404
        return jsonify(product_to_dict(p))

@app.put("/api/products/<int:product_id>")
def update_product(product_id: int):
    data = request.get_json(force=True, silent=True) or {}
    with SessionLocal() as db:
        p = db.get(Product, product_id)
        if not p:
            return jsonify({"error": "not found"}), 404

        if "name" in data:
            name = (data.get("name") or "").strip()
            if not name:
                return jsonify({"error": "name is required"}), 400
            p.name = name

        if "sku" in data:
            sku = (data.get("sku") or "").strip()
            p.sku = sku or None

        if "barcode" in data:
            barcode = (data.get("barcode") or "").strip()
            p.barcode = barcode or None

        if "image_url" in data:
            image_url = (data.get("image_url") or "").strip()
            p.image_url = image_url or None

        if "quantity" in data:
            try:
                p.quantity = int(data.get("quantity") or 0)
            except Exception:
                return jsonify({"error": "quantity must be an integer"}), 400

        db.commit()
        db.refresh(p)
        return jsonify(product_to_dict(p))

@app.delete("/api/products/<int:product_id>")
def delete_product(product_id: int):
    with SessionLocal() as db:
        p = db.get(Product, product_id)
        if not p:
            return jsonify({"error": "not found"}), 404
        db.delete(p)
        db.commit()
        return jsonify({"ok": True})

@app.post("/api/products/<int:product_id>/sales")
def add_sale(product_id: int):
    data = request.get_json(force=True, silent=True) or {}
    try:
        qty = int(data.get("qty_sold") or 0)
    except Exception:
        return jsonify({"error": "qty_sold must be an integer"}), 400
    if qty <= 0:
        return jsonify({"error": "qty_sold must be > 0"}), 400

    d = data.get("date")
    if d:
        try:
            sale_date = datetime.fromisoformat(d).date()
        except Exception:
            return jsonify({"error": "date must be ISO format (YYYY-MM-DD)"}), 400
    else:
        sale_date = date.today()

    with SessionLocal() as db:
        p = db.get(Product, product_id)
        if not p:
            return jsonify({"error": "product not found"}), 404

        s = Sale(product_id=product_id, date=sale_date, qty_sold=qty)
        db.add(s)

        # Optional: auto-decrease stock quantity (common warehouse behavior)
        # If you don't want this, set AUTO_DECREASE_STOCK=0 environment variable.
        auto = os.environ.get("AUTO_DECREASE_STOCK", "1").strip() != "0"
        if auto:
            p.quantity = max(0, (p.quantity or 0) - qty)

        db.commit()
        db.refresh(s)
        return jsonify({
            "id": s.id,
            "product_id": s.product_id,
            "date": s.date.isoformat(),
            "qty_sold": s.qty_sold,
            "created_at": s.created_at.isoformat(),
        }), 201

@app.get("/api/products/<int:product_id>/sales")
def get_sales(product_id: int):
    days = int(request.args.get("days") or 30)
    since = date.today() - timedelta(days=days)

    with SessionLocal() as db:
        p = db.get(Product, product_id)
        if not p:
            return jsonify({"error": "product not found"}), 404

        stmt = (
            select(Sale)
            .where(Sale.product_id == product_id, Sale.date >= since)
            .order_by(Sale.date.desc(), Sale.id.desc())
        )
        sales = db.execute(stmt).scalars().all()
        total = sum(s.qty_sold for s in sales)
        return jsonify({
            "product": product_to_dict(p),
            "days": days,
            "total_qty_sold": int(total),
            "items": [{
                "id": s.id,
                "date": s.date.isoformat(),
                "qty_sold": s.qty_sold,
                "created_at": s.created_at.isoformat(),
            } for s in sales]
        })

@app.get("/api/summary")
def summary():
    days = int(request.args.get("days") or 30)
    since = date.today() - timedelta(days=days)

    with SessionLocal() as db:
        sales_subq = (
            select(Sale.product_id, func.coalesce(func.sum(Sale.qty_sold), 0).label("sales_sum"))
            .where(Sale.date >= since)
            .group_by(Sale.product_id)
            .subquery()
        )

        stmt = (
            select(Product, func.coalesce(sales_subq.c.sales_sum, 0).label("sales_sum"))
            .outerjoin(sales_subq, Product.id == sales_subq.c.product_id)
            .order_by(desc(func.coalesce(sales_subq.c.sales_sum, 0)), func.lower(Product.name))
        )

        rows = db.execute(stmt).all()
        return jsonify({
            "days": days,
            "items": [product_to_dict(p, last30_sales=s) for (p, s) in rows]
        })


# ---------------- Uzum Seller OpenAPI integration ----------------
import json as _json
from urllib import request as _ureq
from urllib import parse as _uparse

def _pick(obj, keys):
    for k in keys:
        v = obj.get(k) if isinstance(obj, dict) else None
        if v is not None and v != "":
            return v
    return None

def _first(arr):
    return arr[0] if isinstance(arr, list) and arr else None

def _extract_products(payload):
    # Uzum commonly returns {"productList":[...]} but can be nested.
    if isinstance(payload, dict):
        if isinstance(payload.get("productList"), list):
            return payload["productList"]
        for k in ("items", "products", "list", "rows", "content"):
            if isinstance(payload.get(k), list):
                return payload[k]
        # recursive search
        for v in payload.values():
            res = _extract_products(v)
            if res is not None:
                return res
    elif isinstance(payload, list):
        return payload
    return None

def _normalize_uzum_product(p):
    # Best-effort mapping; fields differ across versions.
    uzum_product_id = _pick(p, ["productId", "id", "product_id"])
    name = _pick(p, ["name", "title", "productName", "fullName"]) or f"Uzum product {uzum_product_id}"
    sku = _pick(p, ["sku", "productSku", "vendorCode", "sellerSku", "merchantSku", "offerId"])
    barcode = _pick(p, ["barcode", "ean", "gtin"]) or _first(p.get("barcodes") if isinstance(p, dict) else None) or _first(p.get("barcodeList") if isinstance(p, dict) else None)
    qty = _pick(p, ["quantity", "qty", "stock", "available", "availableAmount", "remain"])
    # image candidates
    img = _pick(p, ["imageUrl", "image_url", "photoUrl", "photo_url", "thumbnailUrl", "thumbnail_url", "image", "photo", "thumbnail"])
    if not img and isinstance(p, dict):
        cand = _first(p.get("images")) or _first(p.get("photos")) or _first(p.get("pictureUrls")) or _first(p.get("productImages"))
        if isinstance(cand, str):
            img = cand
        elif isinstance(cand, dict):
            img = cand.get("url") or cand.get("link")
    try:
        quantity = int(qty) if qty is not None else 0
    except Exception:
        quantity = 0
    return {
        "uzum_product_id": int(uzum_product_id) if uzum_product_id is not None else None,
        "name": name,
        "sku": sku,
        "barcode": barcode,
        "quantity": quantity,
        "image_url": img,
    }

def _http_get_json(url):
    req = _ureq.Request(url, method="GET")
    with _ureq.urlopen(req, timeout=30) as resp:
        data = resp.read().decode("utf-8", errors="replace")
        return _json.loads(data)

@app.get("/api/uzum/config")
def uzum_config():
    return jsonify({
        "worker_base": os.environ.get("UZUM_WORKER_BASE", "").strip(),
        "has_worker_base": bool(os.environ.get("UZUM_WORKER_BASE", "").strip()),
        "note": "Set UZUM_WORKER_BASE env var to your Cloudflare Worker URL (no trailing slash) to enable sync."
    })

@app.get("/api/uzum/raw-products")
def uzum_raw_products():
    shop_id = (request.args.get("shop_id") or "").strip()
    page = (request.args.get("page") or "0").strip()
    size = (request.args.get("size") or "50").strip()
    worker_base = (request.args.get("worker_base") or os.environ.get("UZUM_WORKER_BASE") or "").strip().rstrip("/")
    if not worker_base:
        return jsonify({"error": "UZUM_WORKER_BASE is not set and worker_base param is empty"}), 400
    if not shop_id:
        return jsonify({"error": "shop_id is required"}), 400
    url = f"{worker_base}/v1/product/shop/{_uparse.quote(shop_id)}?page={_uparse.quote(page)}&size={_uparse.quote(size)}"
    raw = _http_get_json(url)
    return jsonify(raw)

@app.post("/api/uzum/sync")
def uzum_sync():
    """
    Pull products from Uzum via your Cloudflare Worker and upsert into local warehouse DB.
    Body:
      { "shop_id": "5983", "page": 0, "size": 50, "worker_base": "https://...workers.dev" }
    """
    data = request.get_json(force=True, silent=True) or {}
    shop_id = str(data.get("shop_id") or "").strip()
    page = str(data.get("page") if data.get("page") is not None else "0").strip()
    size = str(data.get("size") if data.get("size") is not None else "50").strip()
    worker_base = str(data.get("worker_base") or os.environ.get("UZUM_WORKER_BASE") or "").strip().rstrip("/")

    if not worker_base:
        return jsonify({"error": "Set env UZUM_WORKER_BASE or pass worker_base in body"}), 400
    if not shop_id:
        return jsonify({"error": "shop_id is required"}), 400

    sync_all = bool(data.get("sync_all", True))
    # Safety cap to avoid infinite loops if API misbehaves
    max_pages = int(data.get("max_pages") or 500)

    try:
        page_i = int(page)
    except Exception:
        page_i = 0
    try:
        size_i = int(size)
    except Exception:
        size_i = 50
    if size_i <= 0:
        size_i = 50

    created = 0
    updated = 0
    fetched_total = 0
    pages_synced = 0

    with SessionLocal() as db:
        cur_page = page_i
        while True:
            url = f"{worker_base}/v1/product/shop/{_uparse.quote(shop_id)}?page={_uparse.quote(str(cur_page))}&size={_uparse.quote(str(size_i))}"
            raw = _http_get_json(url)
            items = _extract_products(raw) or []
            if not items:
                break

            normalized = [_normalize_uzum_product(p) for p in items if isinstance(p, dict)]
            fetched_total += len(items)
            pages_synced += 1

            for it in normalized:
                # Try match by SKU, then barcode, then name
                if it["sku"]:
                    q = select(Product).where(Product.sku == it["sku"])
                elif it["barcode"]:
                    q = select(Product).where(Product.barcode == it["barcode"])
                else:
                    q = select(Product).where(func.lower(Product.name) == (it["name"] or "").strip().lower())

                existing = db.execute(q).scalars().first()

                if existing:
                    existing.name = it["name"] or existing.name
                    existing.sku = it["sku"] or existing.sku
                    existing.barcode = it["barcode"] or existing.barcode
                    existing.quantity = int(it["quantity"] or 0)
                    existing.image_url = it["image_url"] or existing.image_url
                    updated += 1
                else:
                    db.add(Product(
                        name=it["name"],
                        sku=it["sku"],
                        barcode=it["barcode"],
                        quantity=int(it["quantity"] or 0),
                        image_url=it["image_url"],
                    ))
                    created += 1

            # If user wants only one page, stop after first fetch
            if not sync_all:
                break

            # Stop when we reached the last page
            if len(items) < size_i:
                break

            # Stop if safety cap reached
            if pages_synced >= max_pages:
                break

            cur_page += 1

        db.commit()

    return jsonify({
        "ok": True,
        "shop_id": shop_id,
        "sync_all": sync_all,
        "start_page": page_i,
        "pages_synced": pages_synced,
        "fetched": fetched_total,
        "upserted_created": created,
        "upserted_updated": updated,
        "max_pages": max_pages
    })

# ----------------------------------------------------------------


if __name__ == "__main__":
    # For LAN access: set HOST=0.0.0.0
    host = os.environ.get("HOST", "127.0.0.1")
    port = int(os.environ.get("PORT", "5000"))
    app.run(host=host, port=port, debug=True)
